<?php

namespace App\Http\Controllers;

use App\Libraries\MasterIndia\EwayBills;
use Illuminate\Http\Request;
use App\Models\User;
use Debugbar;
use Smalot\PdfParser\Parser;

class HomeController extends Controller {
  /**
   * Create a new controller instance.
   *
   * @return void
   */
  public function __construct() {
    $this->middleware('auth');
  }

  /**
   * Show the application dashboard.
   *
   * @return \Illuminate\Contracts\Support\Renderable
   */
  public function index() {

        $pdfFilePath = public_path('1.pdf');
    // Create an instance of the PDFParser
        $PDFParser = new Parser();

        // Create an instance of the PDF with the parseFile method of the parser
        // this method expects as first argument the path to the PDF file
        $pdf = $PDFParser->parseFile($pdfFilePath);

        $text = $pdf->getText();
    $text = str_replace(" ", "", $text);
    var_dump($text);
    exit;
        
        // Extract ALL text with the getText method
        // Retrieve all pages from the pdf file.
$pages  = $pdf->getPages();
 
// Loop over each page to extract text.
foreach ($pages as $page) {
    
    
    $text = $page->getText();
    $text = str_replace(" ", "", $text);
    var_dump($text);
    exit;
}
 

        dd($text);
        
  }

  
}
