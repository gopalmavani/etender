import React from 'react';
const ListContext = React.createContext(null);

export default ListContext;
